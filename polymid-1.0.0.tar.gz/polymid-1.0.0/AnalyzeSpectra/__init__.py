from PolyMID.AnalyzeSpectra.Integrate import Integrate
