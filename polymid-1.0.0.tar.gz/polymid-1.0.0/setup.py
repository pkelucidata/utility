from setuptools import setup, find_packages

setup(
    name='PolyMID', 
    version='1.0.0', 
    author='VacantiLab (El)',
    author_email='example@example.com',
    description='',
    url='https://github.com/VacantiLab/PolyMID',
    packages=find_packages(),
    install_requires=[
        'bokeh', 'netCDF4', 'numpy', 'pandas', 'peakutils', 'plotly', 'scipy', 'setuptools' 
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
